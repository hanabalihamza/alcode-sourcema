from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(profile)
admin.site.register(serie)
admin.site.register(quiz)
admin.site.register(question)
admin.site.register(answer)
admin.site.register(recievingMails)
